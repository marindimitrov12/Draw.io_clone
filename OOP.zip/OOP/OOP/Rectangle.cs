﻿using System;
using System.Collections.Generic;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace OOP
{
    class Rectangle:Shape
    {
        public int High { get; set; }
        public int Width { get; set; }
        public Color colour { get; set; } = Color.Aquamarine;
        public Color fill { get; set; } = Color.Black;


        public override Graphics DrawGraphics(Graphics g)
        {
            using (var brush = new SolidBrush(fill))
            using (var pen = new Pen(colour))
            {

                g.DrawRectangle(pen, this.location.X, this.location.Y, Width, High);
                return g;

            }
        }
    }
}
